from pathlib import Path
import json
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent
s=json.loads((ROOT/'results/summary.json').read_text(encoding='utf8'))
m=pd.read_csv(ROOT/'results/metrics.csv')
o=pd.read_csv(ROOT/'results/association_main.csv').set_index('term')
b=pd.read_csv(ROOT/'results/association_bmi_adjusted.csv').set_index('term')
b0=pd.read_csv(ROOT/'results/association_bmi_subset_base.csv').set_index('term')
desc=pd.read_csv(ROOT/'results/descriptive.csv')
raw=pd.read_pickle(ROOT/'data/selected_raw.pkl')
a=pd.read_csv(ROOT/'data/analysis_sample.csv.gz',index_col='source_row')
eligible=raw[raw.DIABETE3.isin([1,3]) & raw._LLCPWT.gt(0)]
excluded=eligible.drop(a.index)
exprev=np.average(excluded.DIABETE3.eq(1),weights=excluded._LLCPWT)
test_prevalence=s['test_weighted_prevalence']
test=pd.read_csv(ROOT/'results/test_predictions.csv.gz')
split=pd.read_csv(ROOT/'results/split.csv',index_col='source_row')['split']
train=a.loc[split.index[split.eq('train')]]
train_prevalence=np.average(train.y,weights=train.weight)
baseline_brier=np.average((test.y-train_prevalence)**2,weights=test.weight)
model=m.iloc[1]
fp_per_thousand=1000*(1-test_prevalence)*(1-model.specificity)
fn_per_thousand=1000*test_prevalence*(1-model.sensitivity)
plt.rcParams.update({'font.family':['Times New Roman','SimSun'],'axes.unicode_minus':False,'font.size':10})
ages=desc[desc.variable.eq('age')]
fig,ax=plt.subplots(figsize=(8,3.4))
ax.plot(range(13),ages.weighted_prevalence*100,'o-',color='#176B87')
ax.set_xticks(range(13),['18–24','25–29','30–34','35–39','40–44','45–49','50–54','55–59','60–64','65–69','70–74','75–79','≥80'],rotation=35)
ax.set(xlabel='年龄（岁）',ylabel='自报糖尿病加权比例（%）');ax.grid(alpha=.2)
fig.tight_layout();fig.savefig(ROOT/'figures/age.png',dpi=180);plt.close(fig)

def table(headers,rows,widths=None,*,caption,label,note=None):
    spec=widths or ('l'+'r'*(len(headers)-1))
    body='\n'.join(' & '.join(map(str,row))+r' \\' for row in rows)
    foot=f'\\par\\smallskip\\begin{{minipage}}{{.92\\linewidth}}\\footnotesize 注：{note}\\end{{minipage}}\n' if note else ''
    return (f'\\begin{{table}}[H]\\centering\\small\n\\caption{{{caption}}}\\label{{tab:{label}}}\n'
            f'\\begin{{tabular}}{{{spec}}}\\toprule\n'+' & '.join(headers)+r' \\ \midrule'+'\n'
            +body+'\n\\bottomrule\\end{tabular}\n'+foot+'\\end{table}\n')
def image(name,caption,width='.88'):
    return '\\begin{figure}[H]\\centering\\includegraphics[width='+width+'\\linewidth]{figures/'+name+'.png}\\caption{'+caption+'}\\label{fig:'+name+'}\\end{figure}\n'

profile=[('年龄≥65岁',a.age.ge(10)),('女性',a.sex.eq(2)),('每日吸烟',a.smoke.eq(1)),
         ('无休闲体力活动',a.activity.eq(2)),('水果摄入不足每日1次',a.fruit.eq(2)),
         ('蔬菜摄入不足每日1次',a.vegetable.eq(2)),('重度饮酒',a.heavy_drink.eq(2))]
profile_groups=[a.index,a.index[a.y.eq(0)],a.index[a.y.eq(1)]]
profile_rows=[[name,*[f'{100*np.average(mask.loc[idx],weights=a.loc[idx,"weight"]):.1f}'
                       for idx in profile_groups]] for name,mask in profile]
def ci(row): return f"{row.OR:.3f}（{row.low:.3f}—{row.high:.3f}）"
labels={'smoke_2.0':'偶尔吸烟 / 每日吸烟','smoke_3.0':'曾吸烟 / 每日吸烟','smoke_4.0':'从未吸烟 / 每日吸烟','activity_2.0':'无运动 / 有运动','fruit_2.0':'水果不足每日一次 / 至少一次','vegetable_2.0':'蔬菜不足每日一次 / 至少一次','heavy_drink_2.0':'重度饮酒 / 非重度饮酒'}
title='健康行为与成人自报糖尿病状态的关联及分类'
values={
    'RAW_N':f"{s['raw_n']:,}",
    'ELIGIBLE_N':f"{s['eligible_n']:,}",
    'ABSTRACT_N':f"{s['complete_n']:,}",
    'POSITIVE_N':f"{s['positive_n']:,}",
    'RETAINED_PCT':f"{100*s['complete_n']/s['eligible_n']:.2f}",
    'PREVALENCE':f"{s['weighted_prevalence']*100:.2f}",
    'EXCLUDED_PREVALENCE':f"{exprev*100:.2f}",
    'ACTIVITY_CI':ci(o.loc['activity_2.0']),
    'FRUIT_OR':f"{o.loc['fruit_2.0','OR']:.3f}",
    'VEGETABLE_OR':f"{o.loc['vegetable_2.0','OR']:.3f}",
    'DRINK_OR':f"{o.loc['heavy_drink_2.0','OR']:.3f}",
    'AUC_BASE':f"{m.auc.iloc[0]:.4f}",
    'AUC_BEHAVIOR':f"{model.auc:.4f}",
    'AUC_GAIN':f"{s['auc_gain']:.4f}",
    'AUC_LOW':f"{s['auc_gain_bootstrap95'][0]:.4f}",
    'AUC_HIGH':f"{s['auc_gain_bootstrap95'][1]:.4f}",
    'AP_BASE':f"{m.ap.iloc[0]:.4f}",
    'AP_BEHAVIOR':f"{model.ap:.4f}",
    'AP_GAIN':f"{model.ap-m.ap.iloc[0]:.4f}",
    'AP_GAP':f"{model.ap-m.ap.iloc[2]:.4f}",
    'BRIER_GAIN':f"{m.brier.iloc[0]-model.brier:.4f}",
    'TEST_N':f"{s['test_n']:,}",
    'SENSITIVITY':f"{100*model.sensitivity:.1f}",
    'SPECIFICITY':f"{100*model.specificity:.1f}",
    'PPV':f"{100*model.ppv:.1f}",
    'FP':f"{fp_per_thousand:.0f}",
    'FN':f"{fn_per_thousand:.0f}",
    'BMI_N':f"{s['bmi_n']:,}",
    'ACTIVITY_BEFORE_BMI':f"{b0.loc['activity_2.0','OR']:.3f}",
    'ACTIVITY_AFTER_BMI':f"{b.loc['activity_2.0','OR']:.3f}",
    'BMI_CI':ci(b.loc['bmi_per5']),
}
values['FLOW']=table(['筛选步骤','记录数'],[
    ['原始调查记录',f"{s['raw_n']:,}"],
    ['排除仅妊娠期糖尿病',f"−{s['excluded_gestational']:,}"],
    ['排除糖尿病前期或临界状态',f"−{s['excluded_prediabetes']:,}"],
    ['排除结局不明或权重无效',f"−{s['raw_n']-s['eligible_n']-s['excluded_gestational']-s['excluded_prediabetes']:,}"],
    ['结局明确且权重有效',f"{s['eligible_n']:,}"],
    ['排除主分析特征缺失',f"−{s['eligible_n']-s['complete_n']:,}"],
    ['纳入完整案例分析',f"{s['complete_n']:,}"],
],caption='研究样本筛选过程',label='flow',note='负值为该步骤排除的记录数，其余为当步保留数。')
values['PROFILE']=table(['特征','总体','未报告确诊','自报确诊'],profile_rows,'lrrr',
    caption=r'按糖尿病状态分组的样本特征（加权构成比，\%）',label='profile',
    note=f"构成比分母为各组加权总数。三组未加权样本数依次为{s['complete_n']:,}、{s['complete_n']-s['positive_n']:,}和{s['positive_n']:,}。")
values['SPLIT']=table(['数据集','未加权人数','用途'],[
    ['训练集',f"{s['train_n']:,}",'拟合编码器和模型'],
    ['验证集',f"{s['validation_n']:,}",'选择分类阈值'],
    ['测试集',f"{s['test_n']:,}",'评价固定模型'],
],'lrl',caption='分层样本划分与用途',label='split')
values['ASSOCIATION']=table(['比较',r'调整后OR（95\% CI）'],
    [[label,ci(o.loc[key])] for key,label in labels.items()],'lr',
    caption='健康行为与自报糖尿病状态的调整后关联',label='association',
    note='OR为优势比，CI为置信区间。模型同时调整人口学变量及其余行为变量。')
values['BMI']=table(['比较','未纳入BMI的OR','纳入BMI的OR'],
    [[labels[k],ci(b0.loc[k]),ci(b.loc[k])] for k in ['activity_2.0','fruit_2.0','vegetable_2.0']],'lrr',
    caption='同一BMI有效子样本中的关联估计比较',label='bmi',note=r'括号内为95\%置信区间。')
performance=[['常数基线','0.5000',f'{test_prevalence:.4f}',f'{baseline_brier:.4f}']]
performance += [[row.model,f'{row.auc:.4f}',f'{row.ap:.4f}',f'{row.brier:.4f}'] for row in m.itertuples()]
values['PERFORMANCE']=table(['模型','ROC-AUC','AP','Brier分数'],performance,
    caption='模型在留出测试集上的加权分类表现',label='performance',
    note='AP为平均精确率。ROC-AUC和AP越高越好，Brier分数越低越好。')
values['THRESHOLD']=table(['模型','阈值','灵敏度','特异度','阳性预测值'],
    [[name,f'{r.threshold:.4f}',f'{r.sensitivity:.3f}',f'{r.specificity:.3f}',f'{r.ppv:.3f}']
     for name,r in zip(['人口学LR','行为LR','梯度提升'],m.itertuples())],
    caption='验证集阈值对应的加权测试集分类指标',label='threshold',
    note='阈值显示至四位小数，测试评价使用未舍入的阈值。')
for key,name,caption,width in [
    ('MISSINGNESS','missingness','结局明确且权重有效样本的变量缺失比例。各变量缺失可以重叠。','.79'),
    ('AGE','age','完整案例中各年龄组的加权自报糖尿病比例。','.78'),
    ('FOREST','association','调整后优势比及95%置信区间。区间采用分层PSU夹心方差估计。','.83'),
    ('CURVES','performance','测试集加权ROC与PR曲线。PR图的水平虚线表示测试集加权阳性比例。','.88'),
    ('CALIBRATION','calibration','测试集的分箱校准曲线。各点对应组内加权平均预测概率及实际阳性比例。','.78'),
]:
    values[key]=image(name,caption.replace('%',r'\%'),width)

import re
template=(ROOT/'manuscript.tex').read_text(encoding='utf8')
tex=re.sub(r'@@([A-Z_]+)@@',lambda match:values[match[1]],template)
(ROOT/'report.tex').write_text(tex,encoding='utf8')
import sys, sklearn, scipy, matplotlib
versions={'Python':sys.version,'pandas':pd.__version__,'numpy':np.__version__,'scikit-learn':sklearn.__version__,'scipy':scipy.__version__,'matplotlib':matplotlib.__version__}
(ROOT/'results/versions.json').write_text(json.dumps(versions,ensure_ascii=False,indent=2),encoding='utf8')
(ROOT/'requirements.txt').write_text('\n'.join(f'{k}=={v}' for k,v in versions.items() if k!='Python')+'\n',encoding='utf8')
(ROOT/'README.md').write_text('''# 健康行为与成人自报糖尿病状态的关联及分类

作者 李则奇，学号 2611210110。

## 复现

Python 3.12 环境安装 requirements.txt 后，运行 `python analyze.py`，再运行 `python build_report.py`。最后在本目录运行 `tools/tectonic.exe report.tex`，生成 report.pdf。首次LaTeX编译需联网获取排版资源。字体使用Windows宋体及Times New Roman。

首次读取使用官方SAS Transport文件，采用pandas分块提取17列。selected_raw.pkl是加速重复运行的中间缓存。analysis_sample.csv.gz保留主分析样本及源行索引。程序从不执行下载的代码。

主分析采用2015年官方原始调查，结局为DIABETE3=1对3，排除2、4、7、9和空值。采用完整案例策略。人口学与行为特征均独热编码。描述和模型使用调查权重，关联区间使用分层PSU夹心估计，Bootstrap增量区间为测试样本重抽稳定性区间。报告中的表格数字来自results文件。

研究报告为report.pdf。manuscript.tex是论文模板，build_report.py从结果生成可直接编译的report.tex。研究网站位于project-site/dist/index.html，运行build_site.py可重新生成。网站依赖见requirements-site.txt，分析方法和复现步骤见研究方法与复现说明.md。
''',encoding='utf8')
print('Report source generated')
