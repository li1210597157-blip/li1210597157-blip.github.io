from pathlib import Path
import json, html
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent
s=json.loads((ROOT/'results/summary.json').read_text(encoding='utf8'))
m=pd.read_csv(ROOT/'results/metrics.csv')
o=pd.read_csv(ROOT/'results/association_main.csv').set_index('term')
b=pd.read_csv(ROOT/'results/association_bmi_adjusted.csv').set_index('term')
b0=pd.read_csv(ROOT/'results/association_bmi_subset_base.csv').set_index('term')
desc=pd.read_csv(ROOT/'results/descriptive.csv')
miss=pd.read_csv(ROOT/'results/missingness.csv')
raw=pd.read_pickle(ROOT/'data/selected_raw.pkl')
a=pd.read_csv(ROOT/'data/analysis_sample.csv.gz',index_col='source_row')
eligible=raw[raw.DIABETE3.isin([1,3])]
excluded=eligible.drop(a.index)
exprev=np.average(excluded.DIABETE3.eq(1),weights=excluded._LLCPWT)
plt.rcParams.update({'font.family':['Times New Roman','SimSun'],'axes.unicode_minus':False,'font.size':10})
ages=desc[desc.variable.eq('age')]
fig,ax=plt.subplots(figsize=(8,3.4))
ax.plot(range(13),ages.weighted_prevalence*100,'o-',color='#176B87')
ax.set_xticks(range(13),['18–24','25–29','30–34','35–39','40–44','45–49','50–54','55–59','60–64','65–69','70–74','75–79','≥80'],rotation=35)
ax.set(xlabel='年龄（岁）',ylabel='自报糖尿病加权比例（%）');ax.grid(alpha=.2)
fig.tight_layout();fig.savefig(ROOT/'figures/age.png',dpi=180);plt.close(fig)

def table(headers,rows,widths=None):
    spec=widths or ('l'+'r'*(len(headers)-1))
    return '\\begin{center}\\small\\begin{tabular}{'+spec+'}\\toprule\n'+' & '.join(headers)+r' \\ \midrule'+'\n'+'\n'.join(' & '.join(map(str,row))+r' \\' for row in rows)+'\n\\bottomrule\\end{tabular}\\end{center}\n'
def image(name,caption,width='.88'):
    return '\\begin{figure}[H]\\centering\\includegraphics[width='+width+'\\linewidth]{figures/'+name+'.png}\\caption{'+caption+'}\\end{figure}\n'
def ci(row): return f"{row.OR:.3f}（{row.low:.3f}—{row.high:.3f}）"
labels={'smoke_2.0':'偶尔吸烟 / 每日吸烟','smoke_3.0':'曾吸烟 / 每日吸烟','smoke_4.0':'从未吸烟 / 每日吸烟','activity_2.0':'无运动 / 有运动','fruit_2.0':'水果不足每日一次 / 至少一次','vegetable_2.0':'蔬菜不足每日一次 / 至少一次','heavy_drink_2.0':'重度饮酒 / 非重度饮酒'}
title='健康行为与成人自报糖尿病状态的关联及分类'
tex=r'''\documentclass[12pt,a4paper]{article}
\usepackage{fontspec,xeCJK}
\setmainfont{Times New Roman}
\setmonofont{Times New Roman}
\setCJKmainfont{SimSun}[AutoFakeBold=2]
\setCJKsansfont{SimSun}[AutoFakeBold=2]
\usepackage{graphicx,booktabs,longtable,amsmath,geometry,hyperref,float}
\geometry{left=2.5cm,right=2.5cm,top=2.5cm,bottom=2.5cm}
\hypersetup{colorlinks=true,linkcolor=black,urlcolor=blue,hypertexnames=false,pdftitle={健康行为与成人自报糖尿病状态的关联及分类},pdfauthor={李则奇}}
\renewcommand{\figurename}{图}
\renewcommand{\tablename}{表}
\renewcommand{\refname}{参考文献}
\renewcommand{\baselinestretch}{1.25}
\setlength{\parindent}{2em}
\setlength{\parskip}{.3em}
\begin{document}
\begin{titlepage}\centering
\vspace*{3cm}
{\fontsize{24}{32}\selectfont\bfseries 健康行为与成人自报糖尿病\\状态的关联及分类\par}
\vspace{1cm}
{\Large 基于 BRFSS 2015 调查数据\par}
\vspace{3cm}
{\large 李则奇\par 学号\quad 2611210110\par}
\vfill {2026年11月\par}
\end{titlepage}
\section*{摘要}
'''
tex+=f'''本研究考察健康行为与成人自报糖尿病状态的关联，以及行为信息在基本人口学信息之外的分类增量价值。使用美国疾病控制与预防中心（CDC）公开发布的2015年行为危险因素监测系统（BRFSS）原始数据，依据官方问卷编码构建结局与特征。原始样本包含{s['raw_n']:,}条记录，主分析纳入{s['complete_n']:,}名信息完整的受访者，其中{s['positive_n']:,}人自报曾被告知患有糖尿病，加权比例为{s['weighted_prevalence']*100:.2f}\\%。

使用调查权重拟合多因素Logistic回归，并按分层和初级抽样单位计算稳健标准误。分类实验按60\\%、20\\%、20\\%分为训练、验证和测试集，对人口学Logistic回归、人口学与行为Logistic回归、梯度提升模型进行比较。无休闲体力活动与更高的糖尿病优势相关，调整后OR为{ci(o.loc['activity_2.0'])}。加入行为变量后，测试集ROC-AUC从{m.auc.iloc[0]:.3f}升至{m.auc.iloc[1]:.3f}，平均精确率从{m.ap.iloc[0]:.3f}升至{m.ap.iloc[1]:.3f}。AUC差值为{s['auc_gain']:.4f}，测试集配对Bootstrap百分位区间为{s['auc_gain_bootstrap95'][0]:.4f}至{s['auc_gain_bootstrap95'][1]:.4f}。

健康行为在基本人口学信息之外提供了小幅分类增益。运动与饮食指标适合用于描述健康状态差异。横断面问卷同时受到确诊后行为改变、未诊断疾病及缺失回答选择的影响，结果应结合这些因素解释。

\\noindent\\textbf{{关键词}}\\quad BRFSS；健康行为；糖尿病；调查权重；Logistic回归
\\section{{研究背景与问题}}
BRFSS通过固定电话和移动电话收集成年人的健康行为、健康状况及医疗服务相关信息。2015年公开数据覆盖美国50个州、哥伦比亚特区、关岛和波多黎各，包含饮食、吸烟、饮酒及体力活动指标，适合开展本研究的变量组合分析\\cite{{cdc}}。

本研究提出两个相互关联的问题。第一，在控制年龄、性别、教育和家庭收入后，不同健康行为与自报糖尿病状态有何关联？第二，在相同训练及测试样本下，加入健康行为能否提高分类表现？前者使用调整后优势比及置信区间刻画关联，后者通过测试集指标评价增量信息。选择2015年是因为该年度同时包含本研究所需的运动、吸烟、饮酒与饮食问卷。本文结果描述该年度的调查情境。

\\section{{数据来源与研究样本}}
\\subsection{{原始文件与结局定义}}
从CDC官方年度页面下载SAS Transport压缩文件\\texttt{{LLCP2015XPT.zip}}，用Python的\\texttt{{pandas.read\\_sas}}分块读取并提取17个分析及抽样设计字段。保留原始压缩包、变量字典、抽样字段和文件SHA-256摘要，建立数据来源记录。全文件读取行数与官方公布的441,456条一致。

结局取自\\texttt{{DIABETE3}}，题意为“是否曾被告知患有糖尿病”。编码1为阳性，编码3为阴性。编码2表示仅妊娠期间被告知糖尿病，编码4表示糖尿病前期或临界状态，均排除于主分析。编码7、9和空值分别涉及不确定、拒答或缺失，作为结局不明排除。该定义保留了问卷的自报诊断性质，包含糖尿病类型未进一步细分的回答\\cite{{codebook}}。
'''
tex+=table(['筛选阶段','保留人数'],[['原始调查记录',f"{s['raw_n']:,}"],['排除仅妊娠期糖尿病',f"−{s['excluded_gestational']:,}"],['排除前期或临界状态',f"−{s['excluded_prediabetes']:,}"],['排除结局不明',f"−{s['raw_n']-s['eligible_n']-s['excluded_gestational']-s['excluded_prediabetes']:,}"],['结局明确且权重有效',f"{s['eligible_n']:,}"],['排除任一主分析特征缺失',f"−{s['eligible_n']-s['complete_n']:,}"],['最终完整案例',f"{s['complete_n']:,}"]])
tex+=r'''\subsection{变量构建}
年龄、教育和收入均按分类变量处理，避免把类别编号当作等距连续值。吸烟分为每日、偶尔、曾吸烟和从未吸烟四类。“曾吸烟”以问卷累计吸烟及当前状态构造。水果指标包括问卷计算变量中的果汁等构成，频次只反映摄入频率。运动指过去30天工作之外的体力活动。重度饮酒采用官方性别相关阈值，成年男性每周超过14杯、成年女性超过7杯。各变量的特殊缺失码按照字典转为空值。
'''
tex+=table(['变量','原字段','处理'],[['年龄',r'\texttt{\_AGEG5YR}','1—13级，14转缺失'],['性别',r'\texttt{SEX}','1男，2女'],['教育',r'\texttt{EDUCA}','保留1—6级'],['家庭收入',r'\texttt{INCOME2}','保留1—8级'],['吸烟',r'\texttt{\_SMOKER3}','保留1—4级'],['休闲体力活动',r'\texttt{\_TOTINDA}','1有，2无'],['水果/蔬菜频次',r'\texttt{\_FRTLT1 / \_VEGLT1}','1每日≥1次，2不足1次'],['重度饮酒',r'\texttt{\_RFDRHV5}','1否，2是'],['BMI（扩展分析）',r'\texttt{\_BMI5}','原值除以100']], 'lll')
tex+=r'''
\section{数据质量与描述性分析}
\subsection{缺失处理与样本构成}
主分析采用完整案例策略，排除9项人口学或行为特征中任意一项没有有效回答的记录。水果及蔬菜还依据官方排除标记去除超出可接受范围的回答。缺失率的分母为结局明确的429,360条记录，各变量缺失可重叠，因此缺失数不能直接相加。年龄和收入区间按类别保留，极端BMI值保留官方清理后的数值，BMI只用于扩展模型。
'''
tex+=image('missingness','结局明确样本中的无有效回答比例。缺失包括拒答、不确定、未询问及无效范围标记。')
tex+=f'''最终保留结局明确样本的{s['complete_n']/s['eligible_n']*100:.2f}\\%。收入无有效回答占17.96\\%，蔬菜频次占11.60\\%，水果频次占9.94\\%，是主要的样本损失来源。纳入样本的加权糖尿病比例为{s['weighted_prevalence']*100:.2f}\\%，被排除的结局明确样本为{exprev*100:.2f}\\%。两者结局比例较接近，但这项比较不能排除行为分布与关联结构上的选择差异。

\\subsection{{年龄分布与疾病状态}}
'''
tex+=image('age','完整案例样本不同年龄组的自报糖尿病加权比例。')
tex+=r'''糖尿病状态随年龄呈明显差异，较高年龄组的比例较高，最高年龄组出现回落。该形态涉及出生队列、诊断机会及存活选择等因素，年龄分组因此作为所有模型的基本特征。

\section{统计分析与分类实验设计}
\subsection{加权关联模型}
描述性比例及关联模型使用最终调查权重\texttt{\_LLCPWT}。回归包含年龄、性别、教育、收入和全部5类健康行为。分类特征采用虚拟变量编码，第一有效类别作为参照。人口学参照分别为18—24岁、男性、教育第1级及收入第1级。吸烟参照为每日吸烟，其他二分类参照依次为有运动、每日水果至少一次、每日蔬菜至少一次、非重度饮酒。

设$p_i$为个体的拟合阳性概率，$x_i$为特征向量，$w_i$为均值标准化后的调查权重。使用加权二项对数似然估计系数，优势比为$\exp(\beta)$。实现中采用$C=10^8$的极弱正则近似无惩罚Logistic回归。标准误使用抽样分层\texttt{\_STSTR}和初级抽样单位\texttt{\_PSU}，与州编码共同构建唯一键。以分层内PSU得分总和形成夹心协方差，使用有放回近似，未使用有限总体修正。样本域外记录在得分中置零，本次未发现单PSU分层。95\%区间采用正态近似。
\[
 A=\sum_i w_i p_i(1-p_i)x_ix_i^\top,\quad
 \widehat V=A^{-1}\!\left[\sum_h\frac{m_h}{m_h-1}
 \sum_j(U_{hj}-\bar U_h)(U_{hj}-\bar U_h)^\top\right]\!A^{-1}.
\]
其中$U_{hj}$为分层$h$内PSU $j$的加权得分总和，$m_h$为PSU数。完整案例域的权重未经缺失选择再校准。

\subsection{分类实验与阈值选择}
以固定随机种子20261108，按结局分层划分训练集、验证集和测试集。三个模型使用完全相同的样本划分。人口学LR包含4项基础变量，人口学与行为LR加入5类行为变量，梯度提升使用相同的9项特征。独热编码仅在训练集拟合。预测模型训练时同样使用均值标准化调查权重，保持调查中的阳性比例。
'''
tex+=table(['数据集','人数','用途'],[['训练集',f"{s['train_n']:,}",'模型参数与编码拟合'],['验证集',f"{s['validation_n']:,}",'选择约登指数最大阈值'],['测试集',f"{s['test_n']:,}",'固定模型的最终评价']],'lrl')
tex+=r'''LR采用$C=1$、最多800次迭代。梯度提升固定120轮、每棵树最多15个叶节点、L2正则系数10，关闭内部提前停止。超参数预先固定，没有搜索测试集最优组合。每个模型在验证集上选择灵敏度与特异度之和最大的阈值，再应用于测试集。

全部评价指标使用测试集调查权重，包括ROC-AUC、平均精确率AP、Brier分数、灵敏度、特异度与阳性预测值。AP按平均精确率定义计算。配对Bootstrap在同一批测试记录上重抽150次，计算加入行为后的AUC差值，以2.5和97.5百分位表示区间。这一区间描述测试样本重抽稳定性，未模拟复杂抽样设计。

\section{结果}
\subsection{健康行为的调整后关联}
'''
tex+=table(['比较',r'调整后OR（95\% CI）'],[[label,ci(o.loc[key])] for key,label in labels.items()],'lr')
tex+=image('association','同时控制人口学变量及其余行为变量后的关联。区间使用分层PSU稳健标准误。')
tex+=f'''无休闲运动者的调整后OR为{o.loc['activity_2.0','OR']:.3f}，水果和蔬菜摄入不足每日一次的OR分别为{o.loc['fruit_2.0','OR']:.3f}和{o.loc['vegetable_2.0','OR']:.3f}。运动指标对应的关联幅度较大。吸烟类别相对于每日吸烟者呈现更高的糖尿病优势，重度饮酒类别则呈较低优势。这些方向需要结合诊断后的戒烟、减少饮酒、疾病类型混合及残余混杂理解。调查记录的是当前或近期行为与既往确诊状态的组合，不能直接据此判断改变某项行为的干预效果。

\\subsection{{BMI扩展分析}}
BMI完整子样本为{s['bmi_n']:,}人。为控制额外样本剔除的影响，在该同一子样本中分别拟合含BMI与不含BMI的模型。BMI以每增加5单位进入模型。以下展示运动及饮食变量的比较，完整系数保存于结果CSV。
'''
tex+=table(['比较','同子样本未加BMI的OR','加入BMI后的OR'],[[labels[k],f'{b0.loc[k,"OR"]:.3f}',f'{b.loc[k,"OR"]:.3f}'] for k in ['activity_2.0','fruit_2.0','vegetable_2.0']],'lrr')
tex+=f'''加入BMI后，无运动的OR为{ci(b.loc['activity_2.0'])}。BMI每增加5单位的OR为{ci(b.loc['bmi_per5'])}。BMI可能与行为及疾病状态同时相关，此扩展分析反映调整变量集合变化后的关联敏感性。

\\subsection{{分类模型的测试集表现}}
'''
tex+=table(['模型','ROC-AUC','AP','Brier'],[[row.model,f'{row.auc:.4f}',f'{row.ap:.4f}',f'{row.brier:.4f}'] for row in m.itertuples()])
tex+=image('performance','同一测试集上的加权ROC及PR曲线。PR虚线为测试集加权阳性比例。')
tex+=f'''行为LR相对于人口学LR的AUC提升为{s['auc_gain']:.4f}，Bootstrap区间为{s['auc_gain_bootstrap95'][0]:.4f}至{s['auc_gain_bootstrap95'][1]:.4f}。AP提高{m.ap.iloc[1]-m.ap.iloc[0]:.4f}，Brier分数降低{m.brier.iloc[0]-m.brier.iloc[1]:.4f}。三项指标一致支持行为信息带来增量，但绝对改善较小。梯度提升的AUC与行为LR接近，AP略低，在本次固定参数实验中没有明显额外优势。

验证集选择的阈值约为0.11—0.13，低于常用的0.5。这反映了样本阳性比例与本实验灵敏度、特异度平衡准则的共同作用。阈值比较用于评价模型的分类行为。
'''
tex+=table(['模型','阈值','灵敏度','特异度','阳性预测值'],[[['人口学LR','行为LR','梯度提升'][i],f'{r.threshold:.3f}',f'{r.sensitivity:.3f}',f'{r.specificity:.3f}',f'{r.ppv:.3f}'] for i,r in enumerate(m.itertuples())])
tex+=f'''行为LR的灵敏度为{m.sensitivity.iloc[1]*100:.1f}\\%，特异度为{m.specificity.iloc[1]*100:.1f}\\%，阳性预测值为{m.ppv.iloc[1]*100:.1f}\\%。在此阈值下，模型标记为阳性者中大部分实际属于自报阴性，说明仅依靠这组问卷信息进行个体分类仍有较多误报。

\\subsection{{概率校准}}
'''
tex+=image('calibration','按各模型预测概率的样本十分位分组，比较组内加权预测概率与加权实际阳性比例。','.85')
tex+=r'''校准图展示模型输出概率与观察比例的一致性。对角线表示两者相等。分组点受分箱方式及高概率组样本量影响，因此与Brier分数结合评估。本次未使用验证集再次校准概率，图中展示原始模型输出。
\section{讨论}
\subsection{关联强度与预测增益}
调整后关联和分类增量回答不同问题。运动及饮食变量可以呈现清楚的组间关联，但年龄、收入等基础变量已经提供较强区分信息。加入行为后AUC仅增加约0.008，表明这组粗粒度行为指标所增加的信息有限。AP与Brier分数的同步改善说明增益并非只出现在单一评价指标上。

\subsection{行为变量的解释}
糖尿病诊断可能促使受访者调整饮食、运动、吸烟和饮酒。行为问卷的测量期与“曾被告知糖尿病”的时间范围并不相同。已患病者的健康行为变化会影响观察到的横断面关联。吸烟和饮酒的反向关系应视为这一设计下的经验发现，并结合体重、其他疾病、诊断机会和未测量因素理解。数据没有在本研究结局中细分糖尿病类型，也没有通过统一血糖检查识别未诊断糖尿病。

\subsection{样本选择与可推广性}
完整案例策略损失约28\%的结局明确记录，收入缺失贡献较大。调查权重纠正了原调查部分抽样与响应差异，但不能自动消除本研究完整案例筛选产生的选择偏差。后续可比较多重插补及缺失类别策略，并在新的调查年份验证模型。本文的随机拆分评价属于同一年度样本内部验证，其性能不能直接外推到其他年份或中国人群。BMI扩展模型采用线性项，进一步研究可用样条描述非线性。

\section{结论}
在BRFSS 2015完整案例样本中，缺乏休闲体力活动、较低的水果与蔬菜摄入频次与较高的自报糖尿病优势相关。在人口学变量之外加入行为指标，改善了加权ROC-AUC、AP及Brier分数，但增量幅度较小。梯度提升模型在本次参数设置下与行为Logistic回归表现接近。结果支持在报告中同时呈现关联估计、分类性能、概率校准和误报代价，并根据横断面测量及缺失选择的特点解释发现。

\section{数据与代码可用性}
\texttt{analyze.py}执行完整分析，\texttt{build\_report.py}读取结果生成LaTeX报告。\texttt{data}保留原始数据及分析样本，\texttt{results}保存关联系数、评价指标、样本划分和测试集预测。随机种子、文件哈希、软件版本及运行命令记录于项目文档。

\begingroup\small\renewcommand{\baselinestretch}{1.05}\selectfont
\begin{thebibliography}{9}
\setlength{\itemsep}{0pt}
\bibitem{cdc} Centers for Disease Control and Prevention. 2015 BRFSS Survey Data and Documentation. \url{https://www.cdc.gov/brfss/annual_data/annual_2015.html}. 访问日期2026年11月8日.
\bibitem{codebook} Centers for Disease Control and Prevention. BRFSS 2015 Codebook Report. \url{https://www.cdc.gov/brfss/annual_data/2015/pdf/codebook15_llcp.pdf}.
\bibitem{variables} Centers for Disease Control and Prevention. BRFSS 2015 Summary Matrix of Calculated Variables. \url{https://www.cdc.gov/brfss/annual_data/2015/summary_matrix_15_version12.html}.
\end{thebibliography}
\endgroup
\end{document}
'''
(ROOT/'report.tex').write_text(tex,encoding='utf8')
import sys, sklearn, scipy, matplotlib
versions={'Python':sys.version,'pandas':pd.__version__,'numpy':np.__version__,'scikit-learn':sklearn.__version__,'scipy':scipy.__version__,'matplotlib':matplotlib.__version__}
(ROOT/'results/versions.json').write_text(json.dumps(versions,ensure_ascii=False,indent=2),encoding='utf8')
(ROOT/'requirements.txt').write_text('\n'.join(f'{k}=={v}' for k,v in versions.items() if k!='Python')+'\n',encoding='utf8')
(ROOT/'README.md').write_text('''# 健康行为与成人自报糖尿病状态的关联及分类

作者 李则奇，学号 2611210110。

## 复现

Python 3.12 环境安装 requirements.txt 后，运行 `python analyze.py`，再运行 `python build_report.py`。最后在本目录运行 `tools/tectonic.exe report.tex`，生成 report.pdf。首次LaTeX编译需联网获取排版资源。字体使用Windows宋体及Times New Roman。

首次读取使用官方SAS Transport文件，采用pandas分块提取17列。selected_raw.pkl是加速重复运行的中间缓存。analysis_sample.csv.gz保留主分析样本及源行索引。程序从不执行下载的代码。

主分析采用2015年官方原始调查，结局为DIABETE3=1对3，排除2、4、7、9和空值。采用完整案例策略。人口学与行为特征均独热编码。描述和模型使用调查权重，关联区间使用分层PSU夹心估计，Bootstrap增量区间为测试样本重抽稳定性区间。报告中的表格数字来自results文件。

研究报告为report.pdf，LaTeX源文件为report.tex。研究网站位于project-site/dist/index.html，运行build_site.py可重新生成。网站依赖见requirements-site.txt，分析方法和复现步骤见研究方法与复现说明.md。
''',encoding='utf8')
print('Report source generated')
