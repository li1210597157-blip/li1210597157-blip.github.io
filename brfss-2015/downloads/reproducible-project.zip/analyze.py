"""Reproducible BRFSS 2015 analysis. Run from any working directory."""
from pathlib import Path
import json, hashlib, zipfile, urllib.request, warnings
import numpy as np
import pandas as pd
from scipy.stats import norm
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.metrics import roc_auc_score, average_precision_score, brier_score_loss, roc_curve, precision_recall_curve, confusion_matrix
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
DATA, OUT, FIG = [ROOT / x for x in ['data', 'results', 'figures']]
for folder in [DATA, OUT, FIG]: folder.mkdir(exist_ok=True)
SEED = 20261108
plt.rcParams.update({'font.family':['Times New Roman','SimSun'], 'axes.unicode_minus':False, 'font.size':10, 'savefig.dpi':180})
columns = ['_STATE','_PSU','_STSTR','_LLCPWT','DIABETE3','_AGEG5YR','SEX','EDUCA','INCOME2','_SMOKER3','_TOTINDA','_FRTLT1','_VEGLT1','_RFDRHV5','_BMI5','_FRUITEX','_VEGETEX']
if not (DATA/'selected_raw.pkl').exists():
    if not (DATA/'LLCP2015XPT.zip').exists():
        urllib.request.urlretrieve('https://www.cdc.gov/brfss/annual_data/2015/files/LLCP2015XPT.zip?download=1', DATA/'LLCP2015XPT.zip')
    with zipfile.ZipFile(DATA/'LLCP2015XPT.zip') as z:
        with z.open(z.namelist()[0]) as f:
            raw = pd.concat([part[columns] for part in pd.read_sas(f,format='xport',chunksize=20000)],ignore_index=True)
    raw.to_pickle(DATA/'selected_raw.pkl')
raw = pd.read_pickle(DATA/'selected_raw.pkl')
assert len(raw)==441456
d = pd.DataFrame(index=raw.index)
valid = {'age':('_AGEG5YR',range(1,14)), 'sex':('SEX',[1,2]), 'education':('EDUCA',range(1,7)), 'income':('INCOME2',range(1,9)), 'smoke':('_SMOKER3',[1,2,3,4]), 'activity':('_TOTINDA',[1,2]), 'fruit':('_FRTLT1',[1,2]), 'vegetable':('_VEGLT1',[1,2]), 'heavy_drink':('_RFDRHV5',[1,2])}
for name,(source,levels) in valid.items(): d[name]=raw[source].where(raw[source].isin(levels))
d.loc[raw['_FRUITEX'].eq(2),'fruit']=np.nan
d.loc[raw['_VEGETEX'].eq(2),'vegetable']=np.nan
d['bmi']=raw['_BMI5']/100
d['y']=raw.DIABETE3.map({1:1,3:0})
d['weight']=raw._LLCPWT
eligible=d.y.notna() & d.weight.gt(0)
baseline=['age','sex','education','income']
behavior=['smoke','activity','fruit','vegetable','heavy_drink']
features=baseline+behavior
pd.DataFrame({'variable':features+['bmi'],'missing_n':[int(d.loc[eligible,c].isna().sum()) for c in features+['bmi']], 'missing_pct':[100*d.loc[eligible,c].isna().mean() for c in features+['bmi']]}).to_csv(OUT/'missingness.csv',index=False)
complete=eligible & d[features].notna().all(axis=1)
a=d.loc[complete].copy()
a.to_csv(DATA/'analysis_sample.csv.gz',index_label='source_row')
summary={'raw_n':len(raw),'eligible_n':int(eligible.sum()),'complete_n':len(a),'positive_n':int(a.y.sum()),'weighted_prevalence':float(np.average(a.y,weights=a.weight)), 'excluded_gestational':int(raw.DIABETE3.eq(2).sum()),'excluded_prediabetes':int(raw.DIABETE3.eq(4).sum()),'seed':SEED,'zip_sha256':hashlib.sha256((DATA/'LLCP2015XPT.zip').read_bytes()).hexdigest()}
print(summary,flush=True)
description=[]
for c in features:
    for value,g in a.groupby(c):
        description.append({'variable':c,'level':int(value),'n':len(g),'positive_n':int(g.y.sum()),'weighted_prevalence':np.average(g.y,weights=g.weight)})
pd.DataFrame(description).to_csv(OUT/'descriptive.csv',index=False)

# Design-based sandwich covariance: stratified PSU score totals, with domain-excluded
# observations contributing zero. With-replacement approximation, no finite correction.
def association(sample, cols, label):
    enc=OneHotEncoder(drop='first',sparse_output=False,handle_unknown='ignore')
    cat=[c for c in cols if c!='bmi']
    x=enc.fit_transform(sample[cat])
    names=list(enc.get_feature_names_out(cat))
    if 'bmi' in cols:
        x=np.column_stack([x,(sample.bmi-25)/5]); names+=['bmi_per5']
    model=LogisticRegression(C=1e8,max_iter=1000,tol=1e-8)
    w=sample.weight.to_numpy()/sample.weight.mean()
    model.fit(x,sample.y,sample_weight=w)
    p=model.predict_proba(x)[:,1]
    X=np.column_stack([np.ones(len(x)),x])
    bread=np.linalg.inv(X.T@((w*p*(1-p))[:,None]*X))
    scores=np.zeros((len(raw),X.shape[1]))
    scores[sample.index]=X*(w*(sample.y.to_numpy()-p))[:,None]
    score_frame=pd.DataFrame(scores)
    score_frame['state']=raw._STATE; score_frame['stratum']=raw._STSTR; score_frame['psu']=raw._PSU
    totals=score_frame.groupby(['state','stratum','psu']).sum()
    meat=np.zeros_like(bread); singleton=0
    for _,group in totals.groupby(level=[0,1]):
        v=group.to_numpy(); m=len(v)
        if m<2: singleton+=1; continue
        v=v-v.mean(axis=0); meat+=m/(m-1)*(v.T@v)
    se=np.sqrt(np.diag(bread@meat@bread))[1:]
    beta=model.coef_[0]
    result=pd.DataFrame({'term':names,'OR':np.exp(beta),'low':np.exp(beta-1.96*se),'high':np.exp(beta+1.96*se),'p':2*norm.sf(abs(beta/se))})
    result.to_csv(OUT/f'association_{label}.csv',index=False)
    return singleton
summary['singleton_strata']=association(a,features,'main')
b=a.dropna(subset=['bmi'])
association(b,features,'bmi_subset_base')
association(b,features+['bmi'],'bmi_adjusted')
summary['bmi_n']=len(b)
print('Associations done',flush=True)

train,rest=train_test_split(a.index,test_size=.4,stratify=a.y,random_state=SEED)
val,test=train_test_split(rest,test_size=.5,stratify=a.loc[rest,'y'],random_state=SEED)
split=pd.Series('train',index=a.index); split.loc[val]='validation'; split.loc[test]='test'
split.to_csv(OUT/'split.csv',header=['split'],index_label='source_row')
metrics=[]; predictions={}; curve_data=[]
model_specs=[('人口学LR',baseline,'lr'),('人口学与行为LR',features,'lr'),('人口学与行为梯度提升',features,'hgb')]
for label,cols,kind in model_specs:
    enc=OneHotEncoder(handle_unknown='ignore',sparse_output=False)
    xt=enc.fit_transform(a.loc[train,cols]); xv=enc.transform(a.loc[val,cols]); xe=enc.transform(a.loc[test,cols])
    model=(LogisticRegression(C=1,max_iter=800) if kind=='lr' else HistGradientBoostingClassifier(max_iter=120,max_leaf_nodes=15,l2_regularization=10,early_stopping=False,random_state=SEED))
    model.fit(xt,a.loc[train,'y'],sample_weight=a.loc[train,'weight']/a.loc[train,'weight'].mean())
    pv=model.predict_proba(xv)[:,1]; pt=model.predict_proba(xe)[:,1]
    fpr,tpr,thresholds=roc_curve(a.loc[val,'y'],pv,sample_weight=a.loc[val,'weight'])
    threshold=float(thresholds[np.argmax(tpr-fpr)])
    y=a.loc[test,'y'].to_numpy(); w=a.loc[test,'weight'].to_numpy(); pred=pt>=threshold
    tn,fp,fn,tp=confusion_matrix(y,pred,sample_weight=w).ravel()
    metrics.append({'model':label,'auc':roc_auc_score(y,pt,sample_weight=w),'ap':average_precision_score(y,pt,sample_weight=w),'brier':brier_score_loss(y,pt,sample_weight=w),'threshold':threshold,'sensitivity':tp/(tp+fn),'specificity':tn/(tn+fp),'ppv':tp/(tp+fp),'accuracy':(tp+tn)/sum([tp,tn,fp,fn])})
    predictions[label]=pt
    print(metrics[-1],flush=True)
pd.DataFrame(metrics).to_csv(OUT/'metrics.csv',index=False)
pd.DataFrame({'source_row':test,'y':y,'weight':w,**predictions}).to_csv(OUT/'test_predictions.csv.gz',index=False)
summary.update({'train_n':len(train),'validation_n':len(val),'test_n':len(test),'test_weighted_prevalence':float(np.average(y,weights=w))})
# Paired bootstrap is a test-sample stability measure, not a survey-design CI.
rng=np.random.default_rng(SEED); diffs=[]
for _ in range(150):
    idx=rng.integers(0,len(y),len(y))
    diffs.append(roc_auc_score(y[idx],predictions['人口学与行为LR'][idx],sample_weight=w[idx])-roc_auc_score(y[idx],predictions['人口学LR'][idx],sample_weight=w[idx]))
summary['auc_gain']=metrics[1]['auc']-metrics[0]['auc']
summary['auc_gain_bootstrap95']=np.quantile(diffs,[.025,.975]).tolist()
summary['bootstrap_repeats']=150

fig,axs=plt.subplots(1,2,figsize=(10,4))
for label,p in predictions.items():
    f,t,_=roc_curve(y,p,sample_weight=w); axs[0].plot(f,t,label=label)
    pr,re,_=precision_recall_curve(y,p,sample_weight=w); axs[1].plot(re,pr,label=label)
axs[0].plot([0,1],[0,1],'--',color='grey');axs[1].axhline(np.average(y,weights=w),ls='--',color='grey')
for ax in axs: ax.legend(fontsize=8);ax.grid(alpha=.2)
axs[0].set(xlabel='假阳性率',ylabel='真阳性率',title='调查权重加权 ROC 曲线')
axs[1].set(xlabel='召回率',ylabel='精确率',title='调查权重加权 PR 曲线')
fig.tight_layout();fig.savefig(FIG/'performance.png');plt.close(fig)
fig,ax=plt.subplots(figsize=(6,4))
for label,p in predictions.items():
    bins=np.unique(np.quantile(p,np.linspace(0,1,11))); group=np.digitize(p,bins[1:-1])
    points=[(np.average(p[group==i],weights=w[group==i]),np.average(y[group==i],weights=w[group==i])) for i in np.unique(group)]
    xx,yy=zip(*points);ax.plot(xx,yy,'o-',label=label)
ax.plot([0,.6],[0,.6],'--',color='grey');ax.set(xlabel='平均预测概率',ylabel='实际加权阳性比例',title='测试集校准图');ax.legend(fontsize=8);ax.grid(alpha=.2)
fig.tight_layout();fig.savefig(FIG/'calibration.png');plt.close(fig)
names={'smoke_2.0':'偶尔吸烟 / 每日吸烟','smoke_3.0':'曾吸烟 / 每日吸烟','smoke_4.0':'从未吸烟 / 每日吸烟','activity_2.0':'无运动 / 有运动','fruit_2.0':'水果不足每日一次 / 至少一次','vegetable_2.0':'蔬菜不足每日一次 / 至少一次','heavy_drink_2.0':'重度饮酒 / 非重度饮酒'}
ors=pd.read_csv(OUT/'association_main.csv'); ors=ors[ors.term.isin(names)]
fig,ax=plt.subplots(figsize=(8,4.3)); ypos=np.arange(len(ors))
ax.errorbar(ors.OR,ypos,xerr=[ors.OR-ors.low,ors.high-ors.OR],fmt='o',color='#176B87',capsize=3)
ax.set_yticks(ypos,[names[x] for x in ors.term]);ax.axvline(1,color='grey',ls='--');ax.set(xlabel='调整后 OR 与 95% 置信区间',title='健康行为与自报糖尿病的关联');ax.grid(axis='x',alpha=.2)
fig.tight_layout();fig.savefig(FIG/'association.png');plt.close(fig)
miss=pd.read_csv(OUT/'missingness.csv');fig,ax=plt.subplots(figsize=(7,3.5));ax.barh(miss.variable,miss.missing_pct,color='#176B87');ax.set(xlabel='无有效回答比例（%）',title='结局明确样本中的变量缺失');fig.tight_layout();fig.savefig(FIG/'missingness.png');plt.close(fig)
(OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
print('Completed',json.dumps(summary,ensure_ascii=False),flush=True)
