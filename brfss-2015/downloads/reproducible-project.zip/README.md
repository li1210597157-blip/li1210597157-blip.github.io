# 健康行为与成人自报糖尿病状态的关联及分类

作者 李则奇，学号 2611210110。

## 复现

Python 3.12 环境安装 requirements.txt 后，运行 `python analyze.py`，再运行 `python build_report.py`。最后在本目录运行 `tools/tectonic.exe report.tex`，生成 report.pdf。首次LaTeX编译需联网获取排版资源。字体使用Windows宋体及Times New Roman。

首次读取使用官方SAS Transport文件，采用pandas分块提取17列。selected_raw.pkl是加速重复运行的中间缓存。analysis_sample.csv.gz保留主分析样本及源行索引。程序从不执行下载的代码。

主分析采用2015年官方原始调查，结局为DIABETE3=1对3，排除2、4、7、9和空值。采用完整案例策略。人口学与行为特征均独热编码。描述和模型使用调查权重，关联区间使用分层PSU夹心估计，Bootstrap增量区间为测试样本重抽稳定性区间。报告中的表格数字来自results文件。

研究报告为report.pdf，LaTeX源文件为report.tex。研究网站位于project-site/dist/index.html，运行build_site.py可重新生成。网站依赖见requirements-site.txt，分析方法和复现步骤见研究方法与复现说明.md。
