"""Build the BRFSS research website from saved analysis results."""
from pathlib import Path
import json, shutil, zipfile
import numpy as np
import pandas as pd
import joblib, shap
from scipy.special import expit
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, average_precision_score, brier_score_loss, roc_curve

ROOT=Path(__file__).resolve().parent
SITE=ROOT/'project-site'; DIST=SITE/'dist'; OUT=ROOT/'results'
for p in [DIST/'assets',DIST/'downloads']:p.mkdir(parents=True,exist_ok=True)
(OUT/'website_versions.json').write_text(json.dumps({'shap':shap.__version__,'joblib':joblib.__version__},indent=2),encoding='utf8')
(ROOT/'requirements-site.txt').write_text(f'-r requirements.txt\nshap=={shap.__version__}\njoblib=={joblib.__version__}\n',encoding='utf8')
a=pd.read_csv(ROOT/'data/analysis_sample.csv.gz',index_col='source_row')
spl=pd.read_csv(OUT/'split.csv',index_col='source_row')['split']
pred=pd.read_csv(OUT/'test_predictions.csv.gz')
metrics=pd.read_csv(OUT/'metrics.csv')
summary=json.loads((OUT/'summary.json').read_text(encoding='utf8'))
cols=['age','sex','education','income','smoke','activity','fruit','vegetable','heavy_drink']
labels=['年龄','性别','教育','家庭收入','吸烟','休闲体力活动','水果频次','蔬菜频次','重度饮酒']
train=a.loc[spl.index[spl.eq('train')]]
pipe=Pipeline([('encoding',OneHotEncoder(handle_unknown='ignore',sparse_output=False)),('model',LogisticRegression(C=1,max_iter=800))])
pipe.fit(train[cols],train.y,model__sample_weight=train.weight/train.weight.mean())
proba=pipe.predict_proba(a.loc[pred.source_row,cols])[:,1]
# Re-fitting the identical fixed specification must reproduce the report.
assert np.allclose(proba,pred['人口学与行为LR'],atol=2e-6)
joblib.dump(pipe,OUT/'behavior_lr_pipeline.joblib')
y=pred.y.to_numpy();w=pred.weight.to_numpy()
paths=[]
for name,color in [('人口学LR','#adbaa9'),('人口学与行为LR','#267c73')]:
 fpr,tpr,_=roc_curve(y,pred[name],sample_weight=w)
 idx=np.unique(np.linspace(0,len(fpr)-1,250).astype(int))
 points=' '.join(f'{40+440*fpr[i]:.2f},{205-180*tpr[i]:.2f}' for i in idx)
 paths.append(f'<polyline points="{points}" fill="none" stroke="{color}" stroke-width="3"/>')
(DIST/'assets/hero-roc.svg').write_text('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 520 235"><path d="M40 25V205H480" fill="none" stroke="#ccd5ce"/><path d="M40 205L480 25" stroke="#b8c2bc" stroke-dasharray="5 6"/>'+''.join(paths)+'<g fill="#64746c" font-size="12" font-family="Times New Roman"><text x="36" y="228">0</text><text x="472" y="228">1</text></g></svg>',encoding='utf8')
prior=float(np.average(train.y,weights=train.weight)); constant=np.full(len(y),prior)
baseline={'model':'无信息基线','auc':roc_auc_score(y,constant,sample_weight=w),'ap':average_precision_score(y,constant,sample_weight=w),'brier':brier_score_loss(y,constant,sample_weight=w),'threshold':.5,'sensitivity':0.,'specificity':1.,'ppv':None,'accuracy':float(np.average(y==0,weights=w))}
rows=[baseline]+metrics.to_dict('records')
thresholds={}; flat=[]
for row in rows:
 name=row['model'];p=constant if name=='无信息基线' else pred[name].to_numpy()
 values=sorted(set([round(t/100,2) for t in range(101)]+[float(row['threshold'])]))
 records=[]
 for t in values:
  positive=p>=t
  masks=[(y==0)&~positive,(y==0)&positive,(y==1)&~positive,(y==1)&positive]
  tn,fp,fn,tp=[float(w[mask].sum()) for mask in masks]
  r={'threshold':t,'sensitivity':tp/(tp+fn),'specificity':tn/(tn+fp),'ppv':tp/(tp+fp) if tp+fp else None,'accuracy':(tp+tn)/w.sum(),'balanced_accuracy':.5*(tp/(tp+fn)+tn/(tn+fp)),'weighted_per1000':[v/w.sum()*1000 for v in [tn,fp,fn,tp]],'counts':[int(mask.sum()) for mask in masks]}
  records.append(r);flat.append({'model':name,**{k:v for k,v in r.items() if k not in ['counts','weighted_per1000']},**dict(zip(['TN','FP','FN','TP'],r['counts']))})
 thresholds[name]=records
pd.DataFrame(flat).to_csv(OUT/'threshold_analysis.csv',index=False)
pd.DataFrame(rows).to_csv(OUT/'website_model_metrics.csv',index=False)
# Global and individual model explanations for one-hot categorical features.
# Interventional Linear SHAP on log-odds, centered on the weighted training mean.
enc=pipe.named_steps['encoding'];model=pipe.named_steps['model']
xt=enc.transform(train[cols]);mean=np.average(xt,axis=0,weights=train.weight)
explainer=shap.LinearExplainer(model,(mean,np.eye(xt.shape[1])),feature_perturbation='interventional')
rng=np.random.default_rng(summary['seed']); chosen=rng.choice(len(pred),size=500,replace=False)
xtest=enc.transform(a.loc[pred.source_row,cols]);sv=np.asarray(explainer.shap_values(xtest[chosen]))
offsets=np.cumsum([0]+[len(c) for c in enc.categories_]);grouped=np.column_stack([sv[:,offsets[i]:offsets[i+1]].sum(axis=1) for i in range(len(cols))])
global_importance=np.average(np.abs(grouped),axis=0,weights=w[chosen])
base=float(explainer.expected_value);cases=[]
for name,idx in [('较低预测概率',int(np.argmin(proba))),('较高预测概率',int(np.argmax(proba)))]:
 v=np.asarray(explainer.shap_values(xtest[idx:idx+1]))[0]
 g=[float(v[offsets[i]:offsets[i+1]].sum()) for i in range(len(cols))]
 assert np.isclose(expit(base+sum(g)),proba[idx])
 cases.append({'label':name,'probability':float(proba[idx]),'base':base,'contributions':g})
explanation={'labels':labels,'global':global_importance.tolist(),'cases':cases,'n':500,'method':'interventional Linear SHAP; log-odds; weighted training mean reference'}
(OUT/'model_explanation.json').write_text(json.dumps(explanation,ensure_ascii=False,indent=2),encoding='utf8')
data={'summary':summary,'metrics':rows,'thresholds':thresholds,'explanation':explanation,'missingness':pd.read_csv(OUT/'missingness.csv').to_dict('records'),'association':pd.read_csv(OUT/'association_main.csv').to_dict('records'),'train_prior':prior}
(DIST/'assets/data.js').write_text('window.PROJECT_DATA = '+json.dumps(data,ensure_ascii=False,allow_nan=False)+';',encoding='utf8')
for f in (SITE/'src').iterdir():shutil.copy2(f,DIST/f.name)
for f in (ROOT/'figures').glob('*.png'):shutil.copy2(f,DIST/'assets'/f.name)
for f in [ROOT/'report.pdf',OUT/'threshold_analysis.csv',OUT/'website_model_metrics.csv'] :shutil.copy2(f,DIST/'downloads'/f.name)
files=[ROOT/n for n in ['analyze.py','build_report.py','build_site.py','report.tex','requirements.txt','requirements-site.txt','README.md','研究方法与复现说明.md']]
files+=list(OUT.glob('*.json'))+list(OUT.glob('association*.csv'))+list(OUT.glob('*metrics.csv'))+[OUT/'threshold_analysis.csv',OUT/'behavior_lr_pipeline.joblib']+list((ROOT/'figures').glob('*.png'))+list((SITE/'src').iterdir())
with zipfile.ZipFile(DIST/'downloads/reproducible-project.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in files:
  if f.exists():z.write(f,f.relative_to(ROOT))
print('Website data built; saved pipeline reproduces report predictions. SHAP additivity verified.')
